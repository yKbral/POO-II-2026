public class ItemPedido {
    private int idItem;
    private Produto produto;
    private int quantidade;

    public ItemPedido(int idItem, Produto produto, int quantidade) {
        this.idItem = idItem;
        this.produto = produto;
        this.quantidade = quantidade;
    }

    public int getIdItem() {
        return idItem;
    }

    public Produto getProduto() {
        return produto;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public double calcularSubtotal() {
        return produto.getPreco() * quantidade;
    }

    @Override
    public String toString() {
        return "ItemPedido{idItem=" + idItem + ", produto=" + produto.getNome() + ", quantidade=" + quantidade + ", subtotal=" + String.format("%.2f", calcularSubtotal()) + "}";
    }
}

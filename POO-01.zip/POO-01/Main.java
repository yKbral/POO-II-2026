/*
 * Sistema de gerenciamento de pedidos da cafeteria
 * Autor: Caio Emmanuel de Araújo Cabral
 */

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static List<Cliente> clientes = new ArrayList<>();
    private static List<Produto> produtos = new ArrayList<>();
    private static List<Pedido> pedidos = new ArrayList<>();
    private static int nextClienteId = 1;
    private static int nextProdutoId = 1;
    private static int nextPedidoId = 1;
    private static int nextItemId = 1;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean continuar = true;

        while (continuar) {
            mostrarMenu();
            System.out.print("Escolha uma opção: ");
            String opcao = scanner.nextLine().trim();

            switch (opcao) {
                case "1":
                    cadastrarCliente(scanner);
                    break;
                case "2":
                    listarClientes();
                    break;
                case "3":
                    buscarClientePorId(scanner);
                    break;
                case "4":
                    removerClientePorId(scanner);
                    break;
                case "5":
                    cadastrarProduto(scanner);
                    break;
                case "6":
                    listarProdutos();
                    break;
                case "7":
                    atualizarPreco(scanner);
                    break;
                case "8":
                    removerProduto(scanner);
                    break;
                case "9":
                    criarPedido(scanner);
                    break;
                case "10":
                    listarPedidos();
                    break;
                case "11":
                    buscarPedidoPorId(scanner);
                    break;
                case "12":
                    cancelarPedido(scanner);
                    break;
                case "13":
                    adicionarItemPedido(scanner);
                    break;
                case "14":
                    listarItensPedido(scanner);
                    break;
                case "15":
                    removerItemPedido(scanner);
                    break;
                case "16":
                    calcularTotalPedido(scanner);
                    break;
                case "0":
                    continuar = false;
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }

            System.out.println();
        }

        scanner.close();
        System.out.println("Programa finalizado.");
    }

    private static void mostrarMenu() {
        System.out.println("===== Sistema de Gerenciamento de Pedidos =====");
        System.out.println("1 - Cadastrar cliente");
        System.out.println("2 - Listar clientes");
        System.out.println("3 - Buscar cliente por id");
        System.out.println("4 - Remover cliente por id");
        System.out.println("5 - Cadastrar produto");
        System.out.println("6 - Listar produtos");
        System.out.println("7 - Atualizar preço do produto");
        System.out.println("8 - Remover produto");
        System.out.println("9 - Criar pedido");
        System.out.println("10 - Listar pedidos");
        System.out.println("11 - Buscar pedido por id");
        System.out.println("12 - Cancelar pedido");
        System.out.println("13 - Adicionar item ao pedido");
        System.out.println("14 - Listar itens de um pedido");
        System.out.println("15 - Remover item de um pedido");
        System.out.println("16 - Calcular total de um pedido");
        System.out.println("0 - Sair");
    }

    private static void cadastrarCliente(Scanner scanner) {
        System.out.print("Nome do cliente: ");
        String nome = scanner.nextLine().trim();
        if (nome.isEmpty()) {
            System.out.println("Erro: nome do cliente não pode ficar vazio.");
            return;
        }

        System.out.print("Telefone do cliente: ");
        String telefone = scanner.nextLine().trim();

        if (buscarClientePorId(nextClienteId) != null) {
            System.out.println("Erro: id de cliente já existente. Tente novamente.");
            return;
        }

        Cliente cliente = new Cliente(nextClienteId++, nome, telefone);
        clientes.add(cliente);
        System.out.println("Cliente cadastrado: " + cliente);
    }

    private static void listarClientes() {
        if (clientes.isEmpty()) {
            System.out.println("Nenhum cliente cadastrado.");
            return;
        }

        System.out.println("Clientes cadastrados:");
        for (Cliente cliente : clientes) {
            System.out.println(cliente);
        }
    }

    private static void buscarClientePorId(Scanner scanner) {
        System.out.print("ID do cliente: ");
        int id = lerInteiro(scanner);
        Cliente cliente = buscarClientePorId(id);
        if (cliente == null) {
            System.out.println("Cliente não encontrado.");
        } else {
            System.out.println(cliente);
        }
    }

    private static Cliente buscarClientePorId(int id) {
        for (Cliente cliente : clientes) {
            if (cliente.getId() == id) {
                return cliente;
            }
        }
        return null;
    }

    private static void removerClientePorId(Scanner scanner) {
        System.out.print("ID do cliente a remover: ");
        int id = lerInteiro(scanner);
        Cliente cliente = buscarClientePorId(id);
        if (cliente == null) {
            System.out.println("Cliente não encontrado.");
            return;
        }

        boolean possuiPedido = false;
        for (Pedido pedido : pedidos) {
            if (pedido.getCliente().getId() == id && !pedido.isCancelado()) {
                possuiPedido = true;
                break;
            }
        }

        if (possuiPedido) {
            System.out.println("Não é possível remover cliente com pedido ativo.");
            return;
        }

        clientes.remove(cliente);
        System.out.println("Cliente removido com sucesso.");
    }

    private static void cadastrarProduto(Scanner scanner) {
        System.out.print("Nome do produto: ");
        String nome = scanner.nextLine().trim();
        if (nome.isEmpty()) {
            System.out.println("Erro: nome do produto não pode ficar vazio.");
            return;
        }

        System.out.print("Preço do produto: ");
        double preco = lerDouble(scanner);
        if (preco <= 0) {
            System.out.println("Erro: preço deve ser maior que zero.");
            return;
        }

        Produto produto = new Produto(nextProdutoId++, nome, preco);
        produtos.add(produto);
        System.out.println("Produto cadastrado: " + produto);
    }

    private static void listarProdutos() {
        if (produtos.isEmpty()) {
            System.out.println("Nenhum produto cadastrado.");
            return;
        }

        System.out.println("Produtos cadastrados:");
        for (Produto produto : produtos) {
            System.out.println(produto);
        }
    }

    private static void atualizarPreco(Scanner scanner) {
        System.out.print("ID do produto: ");
        int id = lerInteiro(scanner);
        Produto produto = buscarProdutoPorId(id);
        if (produto == null) {
            System.out.println("Produto não encontrado.");
            return;
        }

        System.out.print("Novo preço: ");
        double novoPreco = lerDouble(scanner);
        if (novoPreco <= 0) {
            System.out.println("Erro: preço deve ser maior que zero.");
            return;
        }

        produto.setPreco(novoPreco);
        System.out.println("Preço atualizado: " + produto);
    }

    private static void removerProduto(Scanner scanner) {
        System.out.print("ID do produto a remover: ");
        int id = lerInteiro(scanner);
        Produto produto = buscarProdutoPorId(id);
        if (produto == null) {
            System.out.println("Produto não encontrado.");
            return;
        }

        boolean usadoEmPedido = false;
        for (Pedido pedido : pedidos) {
            for (ItemPedido item : pedido.getItens()) {
                if (item.getProduto().getId() == id) {
                    usadoEmPedido = true;
                    break;
                }
            }
            if (usadoEmPedido) {
                break;
            }
        }

        if (usadoEmPedido) {
            System.out.println("Não é possível remover produto que já está em um pedido.");
            return;
        }

        produtos.remove(produto);
        System.out.println("Produto removido com sucesso.");
    }

    private static Produto buscarProdutoPorId(int id) {
        for (Produto produto : produtos) {
            if (produto.getId() == id) {
                return produto;
            }
        }
        return null;
    }

    private static void criarPedido(Scanner scanner) {
        System.out.print("ID do cliente para o pedido: ");
        int idCliente = lerInteiro(scanner);
        Cliente cliente = buscarClientePorId(idCliente);
        if (cliente == null) {
            System.out.println("Cliente não encontrado. Pedido não criado.");
            return;
        }

        String data = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));
        Pedido pedido = new Pedido(nextPedidoId++, cliente, data);
        pedidos.add(pedido);
        System.out.println("Pedido criado: " + pedido);
    }

    private static void listarPedidos() {
        if (pedidos.isEmpty()) {
            System.out.println("Nenhum pedido cadastrado.");
            return;
        }

        System.out.println("Pedidos cadastrados:");
        for (Pedido pedido : pedidos) {
            System.out.println(pedido);
        }
    }

    private static void buscarPedidoPorId(Scanner scanner) {
        System.out.print("ID do pedido: ");
        int id = lerInteiro(scanner);
        Pedido pedido = buscarPedidoPorId(id);
        if (pedido == null) {
            System.out.println("Pedido não encontrado.");
        } else {
            System.out.println(pedido);
        }
    }

    private static Pedido buscarPedidoPorId(int id) {
        for (Pedido pedido : pedidos) {
            if (pedido.getId() == id) {
                return pedido;
            }
        }
        return null;
    }

    private static void cancelarPedido(Scanner scanner) {
        System.out.print("ID do pedido a cancelar: ");
        int id = lerInteiro(scanner);
        Pedido pedido = buscarPedidoPorId(id);
        if (pedido == null) {
            System.out.println("Pedido não encontrado.");
            return;
        }
        if (pedido.isCancelado()) {
            System.out.println("Pedido já está cancelado.");
            return;
        }

        pedido.cancelar();
        System.out.println("Pedido cancelado.");
    }

    private static void adicionarItemPedido(Scanner scanner) {
        System.out.print("ID do pedido: ");
        int idPedido = lerInteiro(scanner);
        Pedido pedido = buscarPedidoPorId(idPedido);
        if (pedido == null) {
            System.out.println("Pedido não encontrado.");
            return;
        }
        if (pedido.isCancelado()) {
            System.out.println("Não é possível adicionar itens a um pedido cancelado.");
            return;
        }

        System.out.print("ID do produto: ");
        int idProduto = lerInteiro(scanner);
        Produto produto = buscarProdutoPorId(idProduto);
        if (produto == null) {
            System.out.println("Produto não encontrado.");
            return;
        }

        System.out.print("Quantidade: ");
        int quantidade = lerInteiro(scanner);
        if (quantidade <= 0) {
            System.out.println("Erro: quantidade deve ser maior que zero.");
            return;
        }

        ItemPedido item = new ItemPedido(nextItemId++, produto, quantidade);
        pedido.adicionarItem(item);
        System.out.println("Item adicionado: " + item);
    }

    private static void listarItensPedido(Scanner scanner) {
        System.out.print("ID do pedido: ");
        int idPedido = lerInteiro(scanner);
        Pedido pedido = buscarPedidoPorId(idPedido);
        if (pedido == null) {
            System.out.println("Pedido não encontrado.");
            return;
        }

        if (pedido.getItens().isEmpty()) {
            System.out.println("Nenhum item neste pedido.");
            return;
        }

        System.out.println("Itens do pedido " + idPedido + ":");
        for (ItemPedido item : pedido.getItens()) {
            System.out.println(item);
        }
    }

    private static void removerItemPedido(Scanner scanner) {
        System.out.print("ID do pedido: ");
        int idPedido = lerInteiro(scanner);
        Pedido pedido = buscarPedidoPorId(idPedido);
        if (pedido == null) {
            System.out.println("Pedido não encontrado.");
            return;
        }

        System.out.print("ID do item a remover: ");
        int idItem = lerInteiro(scanner);
        boolean removido = pedido.removerItem(idItem);
        if (removido) {
            System.out.println("Item removido do pedido.");
        } else {
            System.out.println("Item não encontrado no pedido.");
        }
    }

    private static void calcularTotalPedido(Scanner scanner) {
        System.out.print("ID do pedido: ");
        int idPedido = lerInteiro(scanner);
        Pedido pedido = buscarPedidoPorId(idPedido);
        if (pedido == null) {
            System.out.println("Pedido não encontrado.");
            return;
        }

        System.out.printf("Total do pedido %d: R$ %.2f%n", idPedido, pedido.calcularTotal());
    }

    private static int lerInteiro(Scanner scanner) {
        while (true) {
            String linha = scanner.nextLine().trim();
            try {
                return Integer.parseInt(linha);
            } catch (NumberFormatException e) {
                System.out.print("Entrada inválida. Digite um número inteiro: ");
            }
        }
    }

    private static double lerDouble(Scanner scanner) {
        while (true) {
            String linha = scanner.nextLine().trim();
            try {
                return Double.parseDouble(linha.replace(',', '.'));
            } catch (NumberFormatException e) {
                System.out.print("Entrada inválida. Digite um valor numérico: ");
            }
        }
    }
}

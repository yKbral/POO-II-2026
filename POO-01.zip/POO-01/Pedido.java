import java.util.ArrayList;
import java.util.List;

public class Pedido {
    private int id;
    private Cliente cliente;
    private String data;
    private boolean cancelado;
    private List<ItemPedido> itens;

    public Pedido(int id, Cliente cliente, String data) {
        this.id = id;
        this.cliente = cliente;
        this.data = data;
        this.cancelado = false;
        this.itens = new ArrayList<>();
    }

    public int getId() {
        return id;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public String getData() {
        return data;
    }

    public boolean isCancelado() {
        return cancelado;
    }

    public void cancelar() {
        this.cancelado = true;
    }

    public void adicionarItem(ItemPedido item) {
        itens.add(item);
    }

    public boolean removerItem(int idItem) {
        return itens.removeIf(item -> item.getIdItem() == idItem);
    }

    public List<ItemPedido> getItens() {
        return itens;
    }

    public double calcularTotal() {
        double total = 0.0;
        for (ItemPedido item : itens) {
            total += item.calcularSubtotal();
        }
        return total;
    }

    @Override
    public String toString() {
        return "Pedido{id=" + id + ", cliente=" + cliente.getNome() + ", data='" + data + "', status=" + (cancelado ? "CANCELADO" : "ATIVO") + ", total=" + String.format("%.2f", calcularTotal()) + "}";
    }
}
